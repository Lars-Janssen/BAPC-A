fl = int(input().split())
invam = fl[0]
needed = fl[1]
print(invam, needed)

investments = []
for i in range(invam):
    investments.append(input().split())

print(investments)